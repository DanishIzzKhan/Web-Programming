document.addEventListener("DOMContentLoaded", function () {
console.log("Web Wizards loaded");
});